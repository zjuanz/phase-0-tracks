#list of input types
*email
*password
*text
*date
*checkbox
*select 